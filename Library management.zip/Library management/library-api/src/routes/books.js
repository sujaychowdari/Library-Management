const express = require('express');
const db = require('../db');
const { authorize } = require('../middleware/auth');
const { parseId } = require('../utils');

const router = express.Router();

// Adds a computed "status" field so clients see AVAILABLE / UNAVAILABLE
function withStatus(book) {
    return { ...book, status: book.quantity > 0 ? 'AVAILABLE' : 'UNAVAILABLE' };
}

// Returns an error message string, or null if the data is fine
function validateBook(body) {
    const { title, author, category, quantity } = body || {};
    if (typeof title !== 'string' || !title.trim()) return 'Title is required';
    if (typeof author !== 'string' || !author.trim()) return 'Author is required';
    if (typeof category !== 'string' || !category.trim()) return 'Category is required';
    if (!Number.isInteger(quantity) || quantity < 0) {
        return 'Quantity must be a whole number (0 or more)';
    }
    return null;
}

// GET /api/books?category=Programming&search=clean   (any logged-in user)
router.get('/', (req, res) => {
    const { category, search } = req.query;

    let sql = 'SELECT * FROM books WHERE 1=1';
    const params = [];

    if (category) {
        sql += ' AND category = ?';
        params.push(category);
    }
    if (search) {
        sql += ' AND (title LIKE ? OR author LIKE ?)';
        params.push(`%${search}%`, `%${search}%`);
    }

    const books = db.prepare(sql).all(...params);
    res.json(books.map(withStatus));
});

// GET /api/books/:id
router.get('/:id', (req, res) => {
    const id = parseId(req.params.id);
    if (!id) return res.status(400).json({ error: 'Invalid book id' });

    const book = db.prepare('SELECT * FROM books WHERE id = ?').get(id);
    if (!book) return res.status(404).json({ error: 'Book not found' });

    res.json(withStatus(book));
});

// POST /api/books   (ADMIN)
router.post('/', authorize('ADMIN'), (req, res) => {
    const error = validateBook(req.body);
    if (error) return res.status(400).json({ error });

    const { title, author, category, quantity } = req.body;
    const result = db
        .prepare('INSERT INTO books (title, author, category, quantity) VALUES (?, ?, ?, ?)')
        .run(title.trim(), author.trim(), category.trim(), quantity);

    const book = db.prepare('SELECT * FROM books WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(withStatus(book));
});

// PUT /api/books/:id   (ADMIN)
router.put('/:id', authorize('ADMIN'), (req, res) => {
    const id = parseId(req.params.id);
    if (!id) return res.status(400).json({ error: 'Invalid book id' });

    const error = validateBook(req.body);
    if (error) return res.status(400).json({ error });

    const existing = db.prepare('SELECT id FROM books WHERE id = ?').get(id);
    if (!existing) return res.status(404).json({ error: 'Book not found' });

    const { title, author, category, quantity } = req.body;
    db.prepare('UPDATE books SET title = ?, author = ?, category = ?, quantity = ? WHERE id = ?')
        .run(title.trim(), author.trim(), category.trim(), quantity, id);

    const book = db.prepare('SELECT * FROM books WHERE id = ?').get(id);
    res.json(withStatus(book));
});

// DELETE /api/books/:id   (ADMIN)
router.delete('/:id', authorize('ADMIN'), (req, res) => {
    const id = parseId(req.params.id);
    if (!id) return res.status(400).json({ error: 'Invalid book id' });

    const book = db.prepare('SELECT id FROM books WHERE id = ?').get(id);
    if (!book) return res.status(404).json({ error: 'Book not found' });

    const used = db
        .prepare('SELECT COUNT(*) AS n FROM borrow_requests WHERE book_id = ?')
        .get(id).n;
    if (used > 0) {
        return res.status(409).json({ error: 'Cannot delete a book that has borrowing records' });
    }

    db.prepare('DELETE FROM books WHERE id = ?').run(id);
    res.status(204).send(); // 204 = success, nothing to return
});

module.exports = router;