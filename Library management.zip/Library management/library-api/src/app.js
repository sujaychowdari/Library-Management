require('dotenv').config(); // must be first: loads .env into process.env

const express = require('express');
const { authenticate } = require('./middleware/auth');
const authRoutes = require('./routes/auth');
const bookRoutes = require('./routes/books');       
const borrowRoutes = require('./routes/borrows');   

const app = express();

app.use(express.json()); // lets us read JSON bodies via req.body

app.use('/api/auth', authRoutes);                         // public
app.use('/api/books', authenticate, bookRoutes);       
app.use('/api/borrows', authenticate, borrowRoutes);

// Unknown URL → 404
app.use((req, res) => {
    res.status(404).json({ error: 'Route not found' });
});

// Error handler (4 parameters = Express treats it as an error handler)
app.use((err, req, res, next) => {
    const status = err.status || 500;
    if (status === 500) console.error(err);
    res.status(status).json({
        error: status === 500 ? 'Internal server error' : err.message,
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));  