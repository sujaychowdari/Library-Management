const bcrypt = require('bcryptjs');
const db = require('./db');

// Wipe old data (children first, because of foreign keys) and reset ids
db.exec(`
  DELETE FROM borrow_requests;
  DELETE FROM books;
  DELETE FROM users;
  DELETE FROM sqlite_sequence;
`);

const insertUser = db.prepare(
    'INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)'
);
insertUser.run('Library Admin', 'admin@library.com', bcrypt.hashSync('Admin@123', 10), 'ADMIN');
insertUser.run('Alice Student', 'alice@library.com', bcrypt.hashSync('User@123', 10), 'USER');
insertUser.run('Bob Student', 'bob@library.com', bcrypt.hashSync('User@123', 10), 'USER');

const insertBook = db.prepare(
    'INSERT INTO books (title, author, category, quantity) VALUES (?, ?, ?, ?)'
);
const books = [
    ['Clean Code', 'Robert C. Martin', 'Programming', 3],
    ['Introduction to Algorithms', 'Thomas H. Cormen', 'Computer Science', 2],
    ['Operating System Concepts', 'Abraham Silberschatz', 'Computer Science', 4],
    ['Digital Design', 'M. Morris Mano', 'Electronics', 2],
    ['Engineering Mechanics', 'S. Timoshenko', 'Mechanical', 1],
    ['The Pragmatic Programmer', 'Andrew Hunt', 'Programming', 0], // unavailable on purpose
    ['Artificial Intelligence: A Modern Approach', 'Stuart Russell', 'Computer Science', 2],
    ['Wings of Fire', 'A.P.J. Abdul Kalam', 'Biography', 5],
];
books.forEach((b) => insertBook.run(...b));

console.log('Seed complete.');
console.log('Admin: admin@library.com / Admin@123');
console.log('Users: alice@library.com, bob@library.com / User@123');