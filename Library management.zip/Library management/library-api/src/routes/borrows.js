const express = require('express');
const db = require('../db');
const { authorize } = require('../middleware/auth');
const { parseId } = require('../utils');

const router = express.Router();

// Reusable SELECT that joins user + book names into each record
const SELECT_BORROWS = `
  SELECT br.id, br.status, br.requested_at, br.updated_at,
         br.user_id, u.name AS user_name,
         br.book_id, b.title AS book_title
  FROM borrow_requests br
  JOIN users u ON u.id = br.user_id
  JOIN books b ON b.id = br.book_id
`;

function getBorrow(id) {
    return db.prepare(SELECT_BORROWS + ' WHERE br.id = ?').get(id);
}

// Validates :id and loads the request. Returns null (after sending an error) if it fails.
function loadRequest(req, res) {
    const id = parseId(req.params.id);
    if (!id) {
        res.status(400).json({ error: 'Invalid request id' });
        return null;
    }
    const request = db.prepare('SELECT * FROM borrow_requests WHERE id = ?').get(id);
    if (!request) {
        res.status(404).json({ error: 'Borrow request not found' });
        return null;
    }
    return request;
}

// ---------- USER ----------

// POST /api/borrows   body: { "bookId": 1 }
router.post('/', authorize('USER'), (req, res) => {
    const bookId = req.body && req.body.bookId;
    if (!Number.isInteger(bookId) || bookId <= 0) {
        return res.status(400).json({ error: 'bookId must be a positive whole number' });
    }

    const book = db.prepare('SELECT * FROM books WHERE id = ?').get(bookId);
    if (!book) return res.status(404).json({ error: 'Book not found' });

    // Business rule: only available books can be requested
    if (book.quantity <= 0) {
        return res.status(409).json({ error: 'Book is not available' });
    }

    // Extra rule: no duplicate active requests for the same book
    const active = db
        .prepare(`SELECT id FROM borrow_requests
              WHERE user_id = ? AND book_id = ? AND status IN ('PENDING', 'APPROVED')`)
        .get(req.user.id, bookId);
    if (active) {
        return res.status(409).json({ error: 'You already have an active request for this book' });
    }

    // user_id comes from the TOKEN, never from the request body
    const result = db
        .prepare('INSERT INTO borrow_requests (user_id, book_id) VALUES (?, ?)')
        .run(req.user.id, bookId);

    res.status(201).json(getBorrow(result.lastInsertRowid));
});

// GET /api/borrows/my   (only my own records)
router.get('/my', authorize('USER'), (req, res) => {
    const rows = db
        .prepare(SELECT_BORROWS + ' WHERE br.user_id = ? ORDER BY br.id DESC')
        .all(req.user.id);
    res.json(rows);
});

// ---------- ADMIN ----------

// GET /api/borrows?status=PENDING
router.get('/', authorize('ADMIN'), (req, res) => {
    const { status } = req.query;
    const valid = ['PENDING', 'APPROVED', 'REJECTED', 'RETURNED'];

    if (status && !valid.includes(status)) {
        return res.status(400).json({ error: `status must be one of: ${valid.join(', ')}` });
    }

    const rows = status
        ? db.prepare(SELECT_BORROWS + ' WHERE br.status = ? ORDER BY br.id DESC').all(status)
        : db.prepare(SELECT_BORROWS + ' ORDER BY br.id DESC').all();
    res.json(rows);
});

// GET /api/borrows/:id   (owner or admin)  — keep this AFTER '/my' and '/'
router.get('/:id', (req, res) => {
    const id = parseId(req.params.id);
    if (!id) return res.status(400).json({ error: 'Invalid request id' });

    const row = getBorrow(id);
    if (!row) return res.status(404).json({ error: 'Borrow request not found' });

    if (req.user.role !== 'ADMIN' && row.user_id !== req.user.id) {
        return res.status(403).json({ error: 'You can only view your own records' });
    }
    res.json(row);
});

// Two DB changes that must succeed or fail TOGETHER
const approveTx = db.transaction((request) => {
    db.prepare('UPDATE books SET quantity = quantity - 1 WHERE id = ?').run(request.book_id);
    db.prepare(`UPDATE borrow_requests
              SET status = 'APPROVED', updated_at = CURRENT_TIMESTAMP WHERE id = ?`)
        .run(request.id);
});

const returnTx = db.transaction((request) => {
    db.prepare('UPDATE books SET quantity = quantity + 1 WHERE id = ?').run(request.book_id);
    db.prepare(`UPDATE borrow_requests
              SET status = 'RETURNED', updated_at = CURRENT_TIMESTAMP WHERE id = ?`)
        .run(request.id);
});

// PATCH /api/borrows/:id/approve
router.patch('/:id/approve', authorize('ADMIN'), (req, res) => {
    const request = loadRequest(req, res);
    if (!request) return;

    if (request.status !== 'PENDING') {
        return res.status(409).json({ error: `Only PENDING requests can be approved (this one is ${request.status})` });
    }

    const book = db.prepare('SELECT quantity FROM books WHERE id = ?').get(request.book_id);
    if (book.quantity <= 0) {
        return res.status(409).json({ error: 'No copies left to lend' });
    }

    approveTx(request);
    res.json(getBorrow(request.id));
});

// PATCH /api/borrows/:id/reject
router.patch('/:id/reject', authorize('ADMIN'), (req, res) => {
    const request = loadRequest(req, res);
    if (!request) return;

    if (request.status !== 'PENDING') {
        return res.status(409).json({ error: `Only PENDING requests can be rejected (this one is ${request.status})` });
    }

    db.prepare(`UPDATE borrow_requests
              SET status = 'REJECTED', updated_at = CURRENT_TIMESTAMP WHERE id = ?`)
        .run(request.id);
    res.json(getBorrow(request.id));
});

// PATCH /api/borrows/:id/return
router.patch('/:id/return', authorize('ADMIN'), (req, res) => {
    const request = loadRequest(req, res);
    if (!request) return;

    if (request.status !== 'APPROVED') {
        return res.status(409).json({ error: `Only APPROVED requests can be returned (this one is ${request.status})` });
    }

    returnTx(request);
    res.json(getBorrow(request.id));
});

module.exports = router;