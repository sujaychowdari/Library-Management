const jwt = require('jsonwebtoken');

// 1) AUTHENTICATION: "Who are you?"
function authenticate(req, res, next) {
    const header = req.headers.authorization; // expected: "Bearer eyJhbGciOi..."

    if (!header || !header.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Missing or malformed token' });
    }

    const token = header.split(' ')[1];

    try {
        req.user = jwt.verify(token, process.env.JWT_SECRET); // { id, role, iat, exp }
        next(); // token is fine, move on to the next step
    } catch (err) {
        return res.status(401).json({ error: 'Invalid or expired token' });
    }
}

// 2) AUTHORIZATION: "Are you allowed to do this?"
function authorize(...allowedRoles) {
    return (req, res, next) => {
        if (!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({ error: 'Forbidden: you do not have permission' });
        }
        next();
    };
}

module.exports = { authenticate, authorize };