// Turns "5" into 5. Returns null for "abc", "-1", "1.5", "0".
function parseId(value) {
    const id = Number(value);
    return Number.isInteger(id) && id > 0 ? id : null;
}

module.exports = { parseId };